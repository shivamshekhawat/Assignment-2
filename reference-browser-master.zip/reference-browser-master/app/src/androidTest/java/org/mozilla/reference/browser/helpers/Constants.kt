package org.mozilla.reference.browser.helpers

object Constants {
    const val LONG_CLICK_DURATION: Long = 5000
}
