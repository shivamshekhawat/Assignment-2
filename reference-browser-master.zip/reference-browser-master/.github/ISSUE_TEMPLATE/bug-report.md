---
name: "\U0001F41E Bug report"
about: Create a report to help us improve
title: ''
labels: "\U0001F41E bug"
assignees: ''

---

### Steps to reproduce
1.

### Expected behavior
-

### Actual behavior
-

### Device information

* Android device: ?
* Reference Browser version: ?
