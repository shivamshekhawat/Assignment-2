---
name: "💔 Intermittent UI Test Issue"
about: Create an issue to help log a UI test failure
labels: "eng:ui-test, intermittent-test"
title: "Intermittent UI test failure - <Classname.testName>"
assignees: ''

---

### Firebase Test Run:
Provide a Firebase test run report link here showcasing the problem
### Stacktrace:
### Build: 
